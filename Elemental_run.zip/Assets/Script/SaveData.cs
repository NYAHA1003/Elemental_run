using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SaveData
{
    public int gold;
    public int maxS;
    public float speed;
    public int plusS;
    public float gauge;
}
